package org.algorithms;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;

public class ShellSortTest {

    @Test
    void testEmptyArray() {
        int[] arr = {};
        ShellSort.sort(arr, ShellSort.GapSequence.SHELL);
        assertArrayEquals(new int[]{}, arr);
    }

    @Test
    void testSingleElement() {
        int[] arr = {5};
        ShellSort.sort(arr, ShellSort.GapSequence.SHELL);
        assertArrayEquals(new int[]{5}, arr);
    }

    @Test
    void testSortedArray() {
        int[] arr = {1, 2, 3, 4, 5};
        ShellSort.sort(arr, ShellSort.GapSequence.SHELL);
        assertArrayEquals(new int[]{1, 2, 3, 4, 5}, arr);
    }

    @Test
    void testUnsortedArray() {
        int[] arr = {5, 2, 9, 1, 5, 6};
        ShellSort.sort(arr, ShellSort.GapSequence.SHELL);
        assertArrayEquals(new int[]{1, 2, 5, 5, 6, 9}, arr);
    }
}
