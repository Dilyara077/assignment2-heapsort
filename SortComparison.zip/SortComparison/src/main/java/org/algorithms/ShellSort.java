package org.algorithms;

public class ShellSort {

    private static long comparisons = 0;
    private static long swaps = 0;

    public enum GapSequence {SHELL, KNUTH}

    public static void resetMetrics() {
        comparisons = 0;
        swaps = 0;
    }
    public static void sort(int[] array, GapSequence seq) {
        comparisons = 0;
        swaps = 0;

        int n = array.length;
        int gap = (seq == GapSequence.KNUTH) ? 1 : n / 2;

        if (seq == GapSequence.KNUTH) {
            while (gap < n / 3) gap = 3 * gap + 1;
        }

        while (gap > 0) {
            for (int i = gap; i < n; i++) {
                int temp = array[i];
                int j = i;
                while (j >= gap) {
                    comparisons++;
                    if (array[j - gap] > temp) {
                        array[j] = array[j - gap];
                        swaps++;
                        j -= gap;
                    } else {
                        break;
                    }
                }
                array[j] = temp;
            }
            gap = (seq == GapSequence.KNUTH) ? (gap - 1) / 3 : gap / 2;
        }
    }

    public static long getComparisons() {
        return comparisons;
    }

    public static long getSwaps() {
        return swaps;
    }
}