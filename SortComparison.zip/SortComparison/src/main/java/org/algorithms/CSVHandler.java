package org.algorithms;

import java.io.*;
import java.util.*;

public class CSVHandler {

    public static void writeResults(String filename, int[] sortedArray, long comparisons, long swaps) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(filename))) {
            pw.println("Index,Value");
            for (int i = 0; i < sortedArray.length; i++) {
                pw.println(i + "," + sortedArray[i]);
            }
            pw.println();
            pw.println("Comparisons," + comparisons);
            pw.println("Swaps," + swaps);
            System.out.println("Results written to " + filename);
        } catch (IOException e) {
            System.out.println("Error writing to CSV: " + e.getMessage());
        }
    }

    public static List<String[]> readCSV(String filename) {
        List<String[]> data = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                data.add(line.split(","));
            }
        } catch (IOException e) {
            System.out.println("Error reading CSV: " + e.getMessage());
        }
        return data;
    }

    public static void printTable(List<String[]> data) {
        for (String[] row : data) {
            for (String cell : row) {
                System.out.printf("%-15s", cell);
            }
            System.out.println();
        }
    }
}
