package org.algorithms;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtils;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.data.category.DefaultCategoryDataset;

import java.io.PrintWriter;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

public class BenchmarkComparison {
    static final int[] SIZES = {100, 1000, 10000, 100000};
    static final int TRIALS = 5;

    public static void main(String[] args) throws Exception {
        Path outDir = Paths.get("docs", "performance-plots");
        Files.createDirectories(outDir);

        Path rawCsv = outDir.resolve("comparison.csv");
        Path summaryCsv = outDir.resolve("summary_medians.csv");

        try (PrintWriter pw = new PrintWriter(Files.newBufferedWriter(rawCsv))) {
            pw.println("algorithm,n,trial,time_ms,comparisons,swaps,isSorted");
            Random rnd = new Random(42);

            for (int n : SIZES) {
                for (int t = 1; t <= TRIALS; t++) {
                    int[] base = rnd.ints(n, -1_000_000, 1_000_000).toArray();

                    int[] a1 = base.clone();
                    ShellSort.resetMetrics();
                    long t0 = System.nanoTime();
                    ShellSort.sort(a1, ShellSort.GapSequence.KNUTH);
                    long time1 = (System.nanoTime() - t0) / 1_000_000;
                    long comps1 = ShellSort.getComparisons();
                    long swaps1 = ShellSort.getSwaps();

                    pw.printf(Locale.US, "ShellSort,%d,%d,%d,%d,%d,%b%n",
                            n, t, time1, comps1, swaps1, isSorted(a1));

                    int[] a2 = base.clone();
                    HeapSort.resetCounters();
                    t0 = System.nanoTime();
                    HeapSort.sort(a2);
                    long time2 = (System.nanoTime() - t0) / 1_000_000;
                    long comps2 = HeapSort.comparisons;
                    long swaps2 = HeapSort.swaps;

                    pw.printf(Locale.US, "HeapSort,%d,%d,%d,%d,%d,%b%n",
                            n, t, time2, comps2, swaps2, isSorted(a2));

                    System.out.printf("n=%d trial=%d | Shell=%dms Heap=%dms%n", n, t, time1, time2);
                }
            }
        }
        System.out.println("Raw results saved to " + rawCsv);

        List<String> lines = Files.readAllLines(rawCsv).stream()
                .filter(s -> !s.trim().isEmpty())
                .collect(Collectors.toList());
        if (lines.size() < 2) throw new IllegalStateException("No data in " + rawCsv);

        Map<String, List<Long>> timeByKey = new HashMap<>();
        Map<String, List<Long>> compsByKey = new HashMap<>();
        Map<String, List<Long>> swapsByKey = new HashMap<>();

        for (int i = 1; i < lines.size(); i++) {
            String[] p = lines.get(i).split(",");
            String alg = p[0].trim();
            int n = Integer.parseInt(p[1].trim());
            long timeMs = parseLong(p[3]);
            long comps = parseLong(p[4]);
            long swaps = parseLong(p[5]);

            String key = alg + "|" + n;
            timeByKey.computeIfAbsent(key, k -> new ArrayList<>()).add(timeMs);
            compsByKey.computeIfAbsent(key, k -> new ArrayList<>()).add(comps);
            swapsByKey.computeIfAbsent(key, k -> new ArrayList<>()).add(swaps);
        }

        try (PrintWriter pw = new PrintWriter(Files.newBufferedWriter(summaryCsv))) {
            pw.println("algorithm,n,median_time_ms,median_comparisons,median_swaps_or_moves");
            for (String alg : new String[]{"ShellSort", "HeapSort"}) {
                for (int n : SIZES) {
                    String key = alg + "|" + n;
                    long mt = median(timeByKey.get(key));
                    long mc = median(compsByKey.get(key));
                    long ms = median(swapsByKey.get(key));
                    pw.printf(Locale.US, "%s,%d,%d,%d,%d%n", alg, n, mt, mc, ms);
                }
            }
        }
        System.out.println("Summary (medians) saved to " + summaryCsv);

        saveBarChart("Median Time vs n", "Array size (n)", "Time (ms)",
                summaryCsv, outDir.resolve("chart_time_median.png"), "median_time_ms");
        saveBarChart("Median Comparisons vs n", "Array size (n)", "Comparisons",
                summaryCsv, outDir.resolve("chart_comparisons_median.png"), "median_comparisons");
        saveBarChart("Median Swaps/Moves vs n", "Array size (n)", "Swaps/Moves",
                summaryCsv, outDir.resolve("chart_swaps_median.png"), "median_swaps_or_moves");

        System.out.println("Charts saved to " + outDir);
    }

    private static long parseLong(String s) {
        s = s.trim();
        if (s.contains(".")) return Math.round(Double.parseDouble(s));
        return Long.parseLong(s);
    }

    private static long median(List<Long> list) {
        if (list == null || list.isEmpty()) return 0;
        List<Long> a = new ArrayList<>(list);
        Collections.sort(a);
        int m = a.size() / 2;
        if (a.size() % 2 == 1) return a.get(m);
        return Math.round((a.get(m - 1) + a.get(m)) / 2.0);
    }

    private static boolean isSorted(int[] arr) {
        for (int i = 1; i < arr.length; i++)
            if (arr[i - 1] > arr[i]) return false;
        return true;
    }

    private static void saveBarChart(String title, String xLabel, String yLabel,
                                     Path summaryCsv, Path outPng, String metricColumn) throws Exception {
        List<String> lines = Files.readAllLines(summaryCsv).stream()
                .filter(s -> !s.trim().isEmpty())
                .collect(Collectors.toList());
        String[] header = lines.get(0).split(",");
        int cAlg = idx(header, "algorithm");
        int cN   = idx(header, "n");
        int cMet = idx(header, metricColumn);

        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (int i = 1; i < lines.size(); i++) {
            String[] p = lines.get(i).split(",");
            String alg = p[cAlg].trim();
            String nStr = p[cN].trim();
            long val = Long.parseLong(p[cMet].trim());
            dataset.addValue(val, alg, nStr);
        }

        JFreeChart chart = ChartFactory.createBarChart(title, xLabel, yLabel, dataset);
        chart.getCategoryPlot().getDomainAxis().setCategoryLabelPositions(CategoryLabelPositions.UP_45);
        ChartUtils.saveChartAsPNG(outPng.toFile(), chart, 1000, 650);
    }

    private static int idx(String[] header, String name) {
        for (int i = 0; i < header.length; i++)
            if (header[i].trim().equals(name)) return i;
        throw new IllegalArgumentException("Column not found: " + name);
    }
}




